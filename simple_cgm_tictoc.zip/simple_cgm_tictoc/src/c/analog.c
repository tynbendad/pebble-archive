#include <pebble.h>
#include "analog.h"

#define BACKGROUND_COLOR bg_color
#define FOREGROUND_COLOR fg_color
#define ANTIALIASING true

//static Window *s_window;
static Layer *s_simple_bg_layer, *s_date_layer, *s_hands_layer;
static TextLayer *s_day_label, *s_num_label;

static GPath *s_tick_paths[NUM_CLOCK_TICKS];
static GPath *s_minute_arrow, *s_hour_arrow;
static char s_num_buffer[4], s_day_buffer[6];
static GColor bg_color;
static GColor fg_color;
static int use_tictoc;

//static void analog_bg_update_proc(Layer *layer, GContext *ctx) {
//  graphics_context_set_fill_color(ctx, BACKGROUND_COLOR);
//  graphics_fill_rect(ctx, layer_get_bounds(layer), 0, GCornerNone);
//}

static void analog_hands_update_proc(Layer *layer, GContext *ctx) {
  GRect bounds = layer_get_bounds(layer);
  GPoint center = grect_center_point(&bounds);
  center.y -= 19;

  if (!use_tictoc) {
      graphics_context_set_fill_color(ctx, FOREGROUND_COLOR);
      for (int i = 0; i < NUM_CLOCK_TICKS; ++i) {
        const int x_offset = PBL_IF_ROUND_ELSE(18, 0);
        const int y_offset = PBL_IF_ROUND_ELSE(6, 0);
        gpath_move_to(s_tick_paths[i], GPoint(x_offset, y_offset));
        gpath_draw_filled(ctx, s_tick_paths[i]);
      }
    
      const int16_t second_hand_length = PBL_IF_ROUND_ELSE((bounds.size.w / 2) - 19, bounds.size.w / 2);
    
      time_t now = time(NULL);
      struct tm *t = localtime(&now);
      int32_t second_angle = TRIG_MAX_ANGLE * t->tm_sec / 60;
      GPoint second_hand = {
        .x = (int16_t)(sin_lookup(second_angle) * (int32_t)second_hand_length / TRIG_MAX_RATIO) + center.x,
        .y = (int16_t)(-cos_lookup(second_angle) * (int32_t)second_hand_length / TRIG_MAX_RATIO) + center.y,
      };
    
      //// second hand
      //graphics_context_set_stroke_color(ctx, FOREGROUND_COLOR);
      //graphics_draw_line(ctx, second_hand, center);
    
      // minute/hour hand
      graphics_context_set_fill_color(ctx, FOREGROUND_COLOR);
      graphics_context_set_stroke_color(ctx, BACKGROUND_COLOR);
    
      gpath_rotate_to(s_minute_arrow, TRIG_MAX_ANGLE * t->tm_min / 60);
      gpath_draw_filled(ctx, s_minute_arrow);
      // gpath_draw_outline(ctx, s_minute_arrow);
    
      gpath_rotate_to(s_hour_arrow, (TRIG_MAX_ANGLE * (((t->tm_hour % 12) * 6) + (t->tm_min / 10))) / (12 * 6));
      gpath_draw_filled(ctx, s_hour_arrow);
      // gpath_draw_outline(ctx, s_hour_arrow);
    
      // dot in the middle
      graphics_context_set_fill_color(ctx, BACKGROUND_COLOR);
      graphics_fill_rect(ctx, GRect(bounds.size.w / 2 - 1, bounds.size.h / 2 - 1, 3, 3), 0, GCornerNone);
  } else {
#define HAND_MARGIN  10
#define HAND_WIDTH 6
#define FINAL_RADIUS 60
      int s_radius = FINAL_RADIUS;

      graphics_context_set_stroke_width(ctx, HAND_WIDTH);
      graphics_context_set_antialiased(ctx, ANTIALIASING);
    
      time_t now = time(NULL);
      struct tm *t = localtime(&now);

      float minute_angle = TRIG_MAX_ANGLE * t->tm_min / 60;
      float hour_angle;
      hour_angle = TRIG_MAX_ANGLE * (t->tm_hour % 12) / 12;
      hour_angle += (minute_angle / TRIG_MAX_ANGLE) * (TRIG_MAX_ANGLE / 12);
    
      // Plot hands
      GPoint minute_hand = (GPoint) {
        .x = (int16_t)(sin_lookup(TRIG_MAX_ANGLE * t->tm_min / 60) * (int32_t)(s_radius - HAND_MARGIN) / TRIG_MAX_RATIO) + center.x,
        .y = (int16_t)(-cos_lookup(TRIG_MAX_ANGLE * t->tm_min / 60) * (int32_t)(s_radius - HAND_MARGIN) / TRIG_MAX_RATIO) + center.y,
      };
    
#define MARKER_POSITION 60
#define MARKER_RADIUS 2
      graphics_context_set_fill_color(ctx, GColorWhite);
      GPoint marker[12];
      for(int i=0; i<12; i++) {
          float marker_angle = TRIG_MAX_ANGLE * (i % 12) / 12;
          marker[i] = (GPoint) {
            .x = (int16_t)(sin_lookup(marker_angle) * (int32_t)MARKER_POSITION / TRIG_MAX_RATIO) + center.x,
            .y = (int16_t)(-cos_lookup(marker_angle) * (int32_t)MARKER_POSITION / TRIG_MAX_RATIO) + center.y,
          };
          graphics_fill_circle(ctx, marker[i], MARKER_RADIUS);
      }
          
      // Draw hands with positive length only
      graphics_context_set_stroke_color(ctx, FOREGROUND_COLOR);
      if (s_radius > HAND_MARGIN) {
        graphics_draw_line(ctx, center, minute_hand);
      }
      graphics_context_set_stroke_color(ctx, BACKGROUND_COLOR);
      if (s_radius > 2 * HAND_MARGIN) {
#if defined(PBL_BW)
        for (int r=0; r < (s_radius - (2 * HAND_MARGIN)); r+=1) {
            GPoint hour_hand = (GPoint) {
                .x = (int16_t)(sin_lookup(hour_angle) * (int32_t)r / TRIG_MAX_RATIO) + center.x,
                .y = (int16_t)(-cos_lookup(hour_angle) * (int32_t)r / TRIG_MAX_RATIO) + center.y,
            };
            // graphics_context_set_fill_color(ctx, GColorFromRGB(s_color_channels[0], s_color_channels[1], s_color_channels[2]));
            graphics_context_set_fill_color(ctx, BACKGROUND_COLOR);
            graphics_fill_circle(ctx, hour_hand , HAND_WIDTH / 2);
        }
#else
        GPoint hour_hand = (GPoint) {
            .x = (int16_t)(sin_lookup(hour_angle) * (int32_t)(s_radius - (2 * HAND_MARGIN)) / TRIG_MAX_RATIO) + center.x,
            .y = (int16_t)(-cos_lookup(hour_angle) * (int32_t)(s_radius - (2 * HAND_MARGIN)) / TRIG_MAX_RATIO) + center.y,
          };
        graphics_draw_line(ctx, center, hour_hand);
#endif
      }
  }
}

static void analog_date_update_proc(Layer *layer, GContext *ctx) {
  time_t now = time(NULL);
  struct tm *t = localtime(&now);

  strftime(s_day_buffer, sizeof(s_day_buffer), "%a", t);
  text_layer_set_text(s_day_label, s_day_buffer);

  strftime(s_num_buffer, sizeof(s_num_buffer), "%d", t);
  text_layer_set_text(s_num_label, s_num_buffer);
}

//static void analog_handle_second_tick(struct tm *tick_time, TimeUnits units_changed) {
  //layer_mark_dirty(window_get_root_layer(s_window));
//}

void analog_window_load(Layer *window_layer) {
  GRect bounds = layer_get_bounds(window_layer);

  //s_simple_bg_layer = layer_create(bounds);
  //layer_set_update_proc(s_simple_bg_layer, analog_bg_update_proc);
  //layer_add_child(window_layer, s_simple_bg_layer);

  s_date_layer = layer_create(bounds);
  layer_set_update_proc(s_date_layer, analog_date_update_proc);
  layer_add_child(window_layer, s_date_layer);

  // center of PEBBLE TIME display: 72, 84 (size: 144x168); center of ROUND display: 90, 90 (size: 180x180)
  s_day_label = text_layer_create(PBL_IF_ROUND_ELSE(
    GRect(63+55-19, 114-42-19, 27, 20),
    GRect(46+55-19, 114-42-19, 27, 20)));
    // GRect(63, 114, 27, 20),
    // GRect(46, 114, 27, 20)));
  text_layer_set_text(s_day_label, s_day_buffer);
  text_layer_set_background_color(s_day_label, GColorClear);
  text_layer_set_text_color(s_day_label, FOREGROUND_COLOR);
  text_layer_set_font(s_day_label, fonts_get_system_font(FONT_KEY_GOTHIC_18));

  layer_add_child(s_date_layer, text_layer_get_layer(s_day_label));

  s_num_label = text_layer_create(PBL_IF_ROUND_ELSE(
    GRect(90+55-19, 114-42-19, 18, 20),
    GRect(73+55-19, 114-42-19, 18, 20)));
    // GRect(90, 114, 18, 20),
    // GRect(73, 114, 18, 20)));
  text_layer_set_text(s_num_label, s_num_buffer);
  text_layer_set_background_color(s_num_label, GColorClear);
  text_layer_set_text_color(s_num_label, FOREGROUND_COLOR);
  text_layer_set_font(s_num_label, fonts_get_system_font(FONT_KEY_GOTHIC_18_BOLD));

  layer_add_child(s_date_layer, text_layer_get_layer(s_num_label));

  s_hands_layer = layer_create(bounds);
  layer_set_update_proc(s_hands_layer, analog_hands_update_proc);
  layer_add_child(window_layer, s_hands_layer);
}

void analog_window_unload() {
  layer_destroy(s_simple_bg_layer);
  layer_destroy(s_date_layer);

  text_layer_destroy(s_day_label);
  text_layer_destroy(s_num_label);

  layer_destroy(s_hands_layer);
}

void analog_mode(GColor bg, GColor fg, int tictoc) {
  bg_color = bg;
  fg_color = fg;
  use_tictoc = tictoc;
}

void analog_init(Layer *window_layer) {
  // s_window = window_create();
  // window_set_window_handlers(s_window, (WindowHandlers) {
  //   .load = analog_window_load,
  //   .unload = analog_window_unload,
  // });
  // window_stack_push(s_window, true);
    
  s_day_buffer[0] = '\0';
  s_num_buffer[0] = '\0';

  // init hand paths
  s_minute_arrow = gpath_create(&MINUTE_HAND_POINTS);
  s_hour_arrow = gpath_create(&HOUR_HAND_POINTS);

  // Layer *window_layer = window_get_root_layer(s_window);
  GRect bounds = layer_get_bounds(window_layer);
  GPoint center = grect_center_point(&bounds);
  gpath_move_to(s_minute_arrow, center);
  gpath_move_to(s_hour_arrow, center);

  for (int i = 0; i < NUM_CLOCK_TICKS; ++i) {
    s_tick_paths[i] = gpath_create(&ANALOG_BG_POINTS[i]);
  }

  // tick_timer_service_subscribe(SECOND_UNIT, analog_handle_second_tick);
}

void analog_deinit() {
  gpath_destroy(s_minute_arrow);
  gpath_destroy(s_hour_arrow);

  for (int i = 0; i < NUM_CLOCK_TICKS; ++i) {
    gpath_destroy(s_tick_paths[i]);
  }

  // tick_timer_service_unsubscribe();
  // window_destroy(s_window);
}
